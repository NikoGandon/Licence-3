package td1;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import td1.StringUtilitaire;

/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * Rigorous Test :-)
     */
    @Test
    public void limiteAtteinte_chaineTronquee() {
        String input = "The economy is about to";
        int limit = 11;
        Assertions.assertEquals("The economy…", StringUtilitaire.tronquer(input, limit));
    }
}
