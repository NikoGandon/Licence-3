import { Component } from '@angular/core';

@Component({
  selector: 'app-calcul',
  standalone: true,
  imports: [],
  templateUrl: './calcul.component.html',
  styleUrl: './calcul.component.css'
})
export class CalculComponent {

}
